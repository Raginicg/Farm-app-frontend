import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ViewallcomplaintComponent } from './viewallcomplaint.component';

describe('ViewallcomplaintComponent', () => {
  let component: ViewallcomplaintComponent;
  let fixture: ComponentFixture<ViewallcomplaintComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ViewallcomplaintComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ViewallcomplaintComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
