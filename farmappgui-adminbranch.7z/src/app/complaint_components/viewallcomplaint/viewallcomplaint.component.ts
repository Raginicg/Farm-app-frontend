import { AfterViewInit, Component, ViewChild } from '@angular/core';
import { MatPaginator } from '@angular/material/paginator';
import { MatSort } from '@angular/material/sort';
import { MatTable } from '@angular/material/table';
import { ViewcomptableDataSource, ViewcomptableItem } from './viewcomptable-datasource';

@Component({
  selector: 'app-viewallcomplaint',
  templateUrl: './viewallcomplaint.component.html',
  styleUrls: ['./viewallcomplaint.component.css']
})
export class ViewallcomplaintComponent implements AfterViewInit {
  @ViewChild(MatPaginator) paginator!: MatPaginator;
  @ViewChild(MatSort) sort!: MatSort;
  @ViewChild(MatTable) table!: MatTable<ViewcomptableItem>;
  dataSource: ViewcomptableDataSource;

  /** Columns displayed in the table. Columns IDs can be added, removed, or reordered. */
  displayedColumns = ['id', 'name'];

  constructor() { 
    this.dataSource = new ViewcomptableDataSource();
  }
  ngAfterViewInit(): void {
    this.dataSource.sort = this.sort;
    this.dataSource.paginator = this.paginator;
    this.table.dataSource = this.dataSource;
  }

  ngOnInit(): void {
    console.log("works");
  }

  getAllComplaints(){
    
  }
  
}
