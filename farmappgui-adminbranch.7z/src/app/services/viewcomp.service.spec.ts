import { TestBed } from '@angular/core/testing';

import { ViewcompService } from './viewcomp.service';

describe('ViewcompService', () => {
  let service: ViewcompService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(ViewcompService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
