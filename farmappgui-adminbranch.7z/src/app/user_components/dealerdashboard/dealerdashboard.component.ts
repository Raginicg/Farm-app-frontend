import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-dealerdashboard',
  templateUrl: './dealerdashboard.component.html',
  styleUrls: ['./dealerdashboard.component.css']
})
export class DealerdashboardComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
