import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-updatecomplaint',
  templateUrl: './updatecomplaint.component.html',
  styleUrls: ['./updatecomplaint.component.css']
})
export class UpdatecomplaintComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
