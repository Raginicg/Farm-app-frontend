import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-complaintform',
  templateUrl: './complaintform.component.html',
  styleUrls: ['./complaintform.component.css']
})
export class ComplaintformComponent implements OnInit {
  data={
    description:"",
    createdby:""
  }
  constructor() { }
  
  ngOnInit(): void {
  }
  doSubmitForm(){
    console.log("Trying to submit complaint")
    console.log("Complaint is", this.data);
  }

}
