import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ComplainthomeComponent } from './complainthome.component';

describe('ComplainthomeComponent', () => {
  let component: ComplainthomeComponent;
  let fixture: ComponentFixture<ComplainthomeComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ComplainthomeComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ComplainthomeComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
