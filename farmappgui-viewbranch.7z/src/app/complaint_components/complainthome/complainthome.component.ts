import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-complainthome',
  templateUrl: './complainthome.component.html',
  styleUrls: ['./complainthome.component.css']
})
export class ComplainthomeComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
