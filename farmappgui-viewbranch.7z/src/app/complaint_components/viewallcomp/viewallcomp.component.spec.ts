import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ViewallcompComponent } from './viewallcomp.component';

describe('ViewallcompComponent', () => {
  let component: ViewallcompComponent;
  let fixture: ComponentFixture<ViewallcompComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ViewallcompComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ViewallcompComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
