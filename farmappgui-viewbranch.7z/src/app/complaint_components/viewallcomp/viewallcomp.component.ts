import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-viewallcomp',
  templateUrl: './viewallcomp.component.html',
  styleUrls: ['./viewallcomp.component.css']
})
export class ViewallcompComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}

