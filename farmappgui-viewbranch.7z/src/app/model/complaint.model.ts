// export class Complaint{
//     complaintId: number;
//     complainDescription: string;
//     createdBy: string;
  
// }