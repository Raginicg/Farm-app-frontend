import { ViewadItem } from './viewad-item';

describe('ViewadItem', () => {
  it('should create an instance', () => {
    expect(new ViewadItem()).toBeTruthy();
  });
});
