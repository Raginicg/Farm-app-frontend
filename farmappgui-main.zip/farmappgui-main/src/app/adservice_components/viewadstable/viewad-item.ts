export interface ViewadItem {
    advertiseId:number;
    advertiseIdentifier:string;
    availableStock:string;
    offerDescription:string;
    postedBy:string;
}
